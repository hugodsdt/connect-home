<!DOCTYPE html>
<html>
		<head>
		<meta charset="UTF-8" />

		<link rel="stylesheet" href="header_bo.css"/>
		</head>

	<body>
		<header>

		<img class="headerimg" src="Image/logorond.png">
		 <p><nav id="header">
					<div class="headerul">
						<ul class="headerul"> <!-- index de navigation du site -->
				       		<li class= "headerli"><a href="backoffice_articles.php" class = "headera">Articles</a></li>
				        	<li class= "headerli"><a href="backoffice_clients.php" class = "headera">Utilisateurs et Domiciles</a></li>
				        	<li class= "headerli"><a href="backoffice_commandes.php" class = "headera">Commandes</a></li>
									<li class= "headerli"><a href="backoffice_devices_online.php" class = "headera">Capteurs en ligne</a></li>
									<li class= "headerli"><a href="backoffice_pannes.php" class = "headera">Pannes</a></li>
									<li class= "headerli"><a href="backoffice_faq.php" class = "headera">FAQ</a></li>
									<li class= "headerli"><a href="../Controller/deconnexion_bo.php" class="headera">Déconnexion</a></li> <!-- redirige vers la page de connexion après avoir fermé la session -->
				    </ul>
				  </div>
			 </nav>
     </p>
    </header>
	</body>
</html>

<?php
include("Controller/connect.php");
include("View/connexion_bo.php");

 ?>

<!DOCTYPE html>
	<html>
		<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width">
		<link rel="stylesheet" href="../View/header.css"/>
		</head>

		<body>
		<header>


			<a href="accueil.php"><img class="headerimg" src="Image/logorond.png"></a>


			<p>
				<ul class="headerul">
				<div class="leftone">
					<li class= "headerli"><a href="../View/accueil.php" class = "headera">Accueil</a></li>
		        	<li class= "headerli"><a href="../View/capteurs.php" class = "headera">Capteurs & Actionneurs</a></li>
					<li class= "headerli"><a href="../View/catalogue.php" class = "headera">Catalogue</a></li>
					<li class= "headerli"><a href="../View/faq.php" class = "headera">FAQ</a></li>
				</div>
		        <div class="rightone">
		        	<li class= "headerli1"><a href="../Controller/deconnexion.php" class = "headerb">Déconnexion</a></li>
		        </div>

				</ul>

	    	</p>

	    </header>
		</body>
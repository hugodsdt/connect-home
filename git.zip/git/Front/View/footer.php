<!DOCTYPE html>
	<html>
		<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width">
		<link rel="stylesheet" href="../View/footer.css"/>
		</head>

		<body>
    <footer>
			<p><center>Adresse : 28 Rue Notre Dame des Champs, 75006 Paris / Téléphone : 01 49 54 52 00 / Mail : domisep@gmail.com</center>
			</p>
		</footer>
		</body>

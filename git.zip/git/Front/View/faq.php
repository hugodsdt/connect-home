<!DOCTYPE html>
<html>


<head>
	<title>FAQ</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../View/style_tableau.css">
	<link rel="stylesheet" href="accueil3.css">
	  <link rel="icon" type="image/png" href="Image/icon.png" />

</head>
<?php include ('../View/header.php') ?>
<body>
	 
	 <center><h1>Foire aux questions</h1></center>
	 <article>
	 <h2>Vous trouverez ici la réponse à toutes vos questions</h2><hr> 
	
	<?php include ('../Model/modele_FAQ.php') ?><br>
	
	</article>

</body>

<?php include ('../View/footer.php') ?>

</html>
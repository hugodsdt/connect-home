<?php

	echo "Identifiant : " . $_SESSION['id'] . "<br>" . "Nom : " .  $_SESSION['Nom'] . "<br>" . "Prénom : " . $_SESSION['Prenom'] . "<br>" . "Adresse : " . $_SESSION['num_de_rue'].' '. $_SESSION['nom_de_rue'].' '.$_SESSION['Code_postal'].' '.$_SESSION['ville'] . "<br>" . "Mail : " . $_SESSION['mail'];

?>